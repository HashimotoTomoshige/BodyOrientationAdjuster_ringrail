/**********************************************
* 全てのヘッダファイルをインクルード
**********************************************/

#ifndef INCLUDE_FILES_H
#define INCLUDE_FILES_H

#include <iostream>
#include <math.h>
#include <vector>
#include "Eigen/Core"
#include "Eigen/Dense"
#include "Eigen/Geometry"

#endif
